/// <reference types="vite/client" />

// Unified __APP_CONFIG__ type declaration (used by firebase.ts, useFirebaseStorage.ts, and useSystemStorage.ts)
interface FirebaseConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
}

interface SupabaseConfig {
  url: string;
  anonKey: string;
  tablePrefix: string;
}

interface SystemConfig {
  apiUrl: string;
  projectId: string;
  apiToken: string;
  storageEnabled?: boolean;
  maxFileSizeMb?: number;
  internalAiEnabled?: boolean;
  firebase?: FirebaseConfig;
  firebasePrefix?: string;
  supabase?: SupabaseConfig;
}

declare global {
  interface Window {
    __APP_CONFIG__?: SystemConfig;
  }
}

export {};
