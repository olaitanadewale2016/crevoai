import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import './index.css'
import './custom.css'

// Resolve BrowserRouter basename safely across /preview/:id, /app/:id, and custom domains
function resolveBasename(): string {
  const pathname = typeof window !== 'undefined' ? window.location.pathname : '/'
  const baseTag = document.querySelector('base')
  const rawHref = baseTag?.getAttribute('href')
  if (rawHref && rawHref !== '/') {
    const normalized = rawHref.replace(/\/+$/, '')
    if (pathname === normalized || pathname.startsWith(normalized + '/')) {
      return normalized
    }
  }
  const match = pathname.match(/^\/(preview|app)\/[^/]+/)
  if (match) {
    return match[0]
  }
  return '/'
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BrowserRouter basename={resolveBasename()}>
      <App />
    </BrowserRouter>
  </React.StrictMode>,
)
