import { initializeApp, FirebaseApp, getApps } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getAuth, Auth, setPersistence, browserLocalPersistence } from 'firebase/auth';

let db: Firestore | null = null;
let auth: Auth | null = null;

/**
 * Initialize Firebase with the config from __APP_CONFIG__.
 * Returns the Firestore instance or null if config is not available.
 */
export function initFirebase(): Firestore | null {
    const config = typeof window !== 'undefined' ? window.__APP_CONFIG__?.firebase : undefined;

    if (!config) {
        console.warn('Firebase config not found in __APP_CONFIG__');
        return null;
    }

    // Validate config has required fields before initializing
    if (!config.apiKey || !config.projectId || config.apiKey.length < 10) {
        console.warn('Firebase config is incomplete or invalid');
        return null;
    }

    if (db && auth) return db;

    const existingApps = getApps();
    const app: FirebaseApp = existingApps.length > 0
        ? existingApps[0]
        : initializeApp(config);

    db = db || getFirestore(app);

    // Initialize Auth with local persistence (stays logged in on refresh)
    if (!auth) {
        auth = getAuth(app);
        setPersistence(auth, browserLocalPersistence).catch(console.error);
    }

    return db;
}

/**
 * Get the Firestore database instance.
 * Lazily initializes Firebase when __APP_CONFIG__.firebase is present.
 */
export function getDb(): Firestore | null {
    if (!db) {
        initFirebase();
    }
    return db;
}

/**
 * Get the Firebase Auth instance.
 * Lazily initializes Firebase when __APP_CONFIG__.firebase is present.
 */
export function getFirebaseAuth(): Auth | null {
    if (!auth) {
        initFirebase();
    }
    return auth;
}

/**
 * Get the collection prefix for this project.
 * All collections should be prefixed with this to scope data per-project.
 */
export function getCollectionPrefix(): string {
    return typeof window !== 'undefined'
        ? window.__APP_CONFIG__?.firebasePrefix || ''
        : '';
}

/**
 * Reset the Firebase instance (useful for testing or re-initialization).
 */
export function resetFirebase(): void {
    db = null;
    auth = null;
}
