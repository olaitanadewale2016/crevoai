import { initializeApp, FirebaseApp, getApps } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getAuth, Auth, setPersistence, browserLocalPersistence } from 'firebase/auth';
import { getStorage, FirebaseStorage } from 'firebase/storage';

let appInstance: FirebaseApp | null = null;
let db: Firestore | null = null;
let auth: Auth | null = null;
let storage: FirebaseStorage | null = null;

function getRuntimeFirebaseConfig() {
    if (typeof window === 'undefined') return undefined;
    const config = window.__APP_CONFIG__?.firebase;
    if (!config || !config.apiKey || !config.projectId || config.apiKey.length < 10) {
        return undefined;
    }
    return config;
}

/**
 * Returns true when valid Firebase configuration is present in window.__APP_CONFIG__.
 */
export function isFirebaseConfigured(): boolean {
    return Boolean(getRuntimeFirebaseConfig());
}

/**
 * Initialize Firebase with the config from __APP_CONFIG__.
 * Returns the Firestore instance or null if config is not available.
 */
export function initFirebase(): Firestore | null {
    const config = getRuntimeFirebaseConfig();

    if (!config) {
        if (typeof window !== 'undefined' && window.__APP_CONFIG__?.firebase) {
            console.warn('Firebase config is incomplete or invalid');
        }
        return null;
    }

    if (db && auth && (storage || !config.storageBucket)) return db;

    const existingApps = getApps();
    const app: FirebaseApp = existingApps.length > 0
        ? existingApps[0]
        : initializeApp(config);

    appInstance = app;
    db = db || getFirestore(app);

    // Initialize Auth with local persistence (stays logged in on refresh)
    if (!auth) {
        auth = getAuth(app);
        setPersistence(auth, browserLocalPersistence).catch(console.error);
    }

    // Initialize Firebase Storage when storageBucket is configured
    if (!storage && config.storageBucket) {
        try {
            storage = getStorage(app);
        } catch (err) {
            console.warn('Failed to initialize Firebase Storage:', err);
        }
    }

    return db;
}

/**
 * Get the Firestore database instance.
 * Lazily initializes Firebase when __APP_CONFIG__.firebase is present.
 */
export function getDb(): Firestore | null {
    if (!db) {
        initFirebase();
    }
    return db;
}

/**
 * Get the Firebase Auth instance.
 * Lazily initializes Firebase when __APP_CONFIG__.firebase is present.
 */
export function getFirebaseAuth(): Auth | null {
    if (!auth) {
        initFirebase();
    }
    return auth;
}

/**
 * Get the Firebase Storage instance.
 * Lazily initializes Firebase when __APP_CONFIG__.firebase.storageBucket is present.
 */
export function getFirebaseStorage(): FirebaseStorage | null {
    if (!storage) {
        initFirebase();
    }
    return storage;
}

/**
 * Get the initialized FirebaseApp instance.
 */
export function getFirebaseApp(): FirebaseApp | null {
    if (!appInstance) {
        initFirebase();
    }
    return appInstance;
}

/**
 * Get the collection prefix for this project.
 * All collections should be prefixed with this to scope data per-project.
 */
export function getCollectionPrefix(): string {
    return typeof window !== 'undefined'
        ? (window.__APP_CONFIG__?.firebasePrefix || '').replace(/^\/+|\/+$/g, '')
        : '';
}

/**
 * Resolve a collection path with the project's Firebase prefix without double-prefixing.
 */
export function getCollectionPath(collectionName: string): string {
    const cleanPrefix = getCollectionPrefix();
    const cleanCollection = (collectionName || '').replace(/^\/+|\/+$/g, '');
    if (!cleanPrefix || !cleanCollection) return cleanCollection;
    if (cleanCollection === cleanPrefix || cleanCollection.startsWith(`${cleanPrefix}/`)) {
        return cleanCollection;
    }
    return `${cleanPrefix}/${cleanCollection}`;
}

/**
 * Build a user-scoped subcollection path (e.g. "users/<uid>/cycles") relative to the project prefix.
 */
export function getUserCollectionPath(uid: string, collectionName: string): string {
    const cleanUid = (uid || '').replace(/^\/+|\/+$/g, '');
    const cleanCollection = (collectionName || '').replace(/^\/+|\/+$/g, '');
    if (!cleanUid || !cleanCollection) return '';
    return `users/${cleanUid}/${cleanCollection}`;
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
    if (Object.prototype.toString.call(value) !== '[object Object]') {
        return false;
    }
    const proto = Object.getPrototypeOf(value);
    return proto === null || proto === Object.prototype;
}

/**
 * Recursively strips undefined fields from plain objects and arrays before writing to Firestore.
 * Preserves Date, Firestore Timestamp/FieldValue instances, null, and primitive values.
 */
export function sanitizeFirestoreData<T>(value: T): T {
    if (Array.isArray(value)) {
        return value
            .filter((item) => item !== undefined)
            .map((item) => sanitizeFirestoreData(item)) as unknown as T;
    }
    if (isPlainObject(value)) {
        const cleaned: Record<string, unknown> = {};
        for (const [key, val] of Object.entries(value)) {
            if (val !== undefined) {
                cleaned[key] = sanitizeFirestoreData(val);
            }
        }
        return cleaned as T;
    }
    return value;
}

/**
 * Map Firestore SDK error codes to clear, actionable messages.
 */
export function mapFirestoreError(error: unknown): string {
    const code = (error as { code?: string })?.code || '';
    const message = (error as Error)?.message || '';

    if (code === 'permission-denied' || message.includes('Missing or insufficient permissions')) {
        return 'Permission denied by Firestore security rules. Please sign in or deploy the project Firestore security rules in Firebase Console.';
    }
    if (code === 'failed-precondition' || message.includes('requires an index')) {
        return 'Firestore query requires an index. Try sorting data in the app or creating the suggested index in Firebase Console.';
    }
    if (code === 'unauthenticated') {
        return 'Please sign in to save or view your data.';
    }
    if (code === 'unavailable') {
        return 'Firestore is temporarily unavailable. Check your internet connection and try again.';
    }
    if (code === 'not-found') {
        return 'The requested record or Firestore database was not found.';
    }
    return message || 'Database operation failed';
}

/**
 * Reset the Firebase instance (useful for testing or re-initialization).
 */
export function resetFirebase(): void {
    appInstance = null;
    db = null;
    auth = null;
    storage = null;
}
