import * as React from 'react';
import { Button } from './ui/button';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface ErrorBoundaryProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

/**
 * @ai-hint Error boundary component to catch and display errors gracefully.
 * Wrap your app or specific sections to prevent crashes from breaking the entire UI.
 */
export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void {
    console.error('ErrorBoundary caught:', error, errorInfo);
    try {
      window.parent?.postMessage(
        {
          type: 'preview-runtime-error',
          message: error?.message || 'Unexpected runtime error',
          stack: error?.stack || errorInfo?.componentStack || '',
        },
        '*'
      );
    } catch {
      // Ignore postMessage failures
    }
  }

  render(): React.ReactNode {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="min-h-[400px] flex items-center justify-center p-8 bg-background text-foreground">
          <div className="text-center max-w-lg w-full p-6 border rounded-xl shadow-sm bg-card text-card-foreground">
            <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Something went wrong</h2>
            <p className="text-muted-foreground text-sm mb-4">
              {this.state.error?.message || 'An unexpected error occurred while rendering the page.'}
            </p>
            {this.state.error?.stack && (
              <details className="text-left mb-4">
                <summary className="text-xs text-muted-foreground cursor-pointer hover:underline mb-1">
                  View error details
                </summary>
                <pre className="text-[11px] p-3 rounded-lg bg-muted text-muted-foreground overflow-auto max-h-48 whitespace-pre-wrap font-mono">
                  {this.state.error.stack}
                </pre>
              </details>
            )}
            <div className="flex gap-3 justify-center">
              <Button
                variant="outline"
                size="sm"
                onClick={() => this.setState({ hasError: false, error: undefined })}
              >
                Try Again
              </Button>
              <Button
                size="sm"
                onClick={() => window.location.reload()}
                className="gap-2"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Refresh Page
              </Button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
