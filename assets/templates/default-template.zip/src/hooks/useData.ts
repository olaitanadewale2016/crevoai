import { useMemo } from 'react';
import { useFirestore, UseFirestoreOptions } from './useFirestore';
import { isFirebaseConfigured } from '../lib/firebase';

/**
 * @ai-marker AUTO_SWITCH_DATA
 * Auto-switching data hook - uses Firestore when Firebase is enabled,
 * falls back to localStorage persistence and sample data when disabled.
 *
 * Usage:
 * const { data, loading, error, isLive } = useData('posts', SAMPLE_POSTS);
 */
export function useData<T extends { id?: string | number }>(
  collectionName: string,
  sampleData: T[],
  options?: Omit<UseFirestoreOptions, 'enabled'>
): {
  data: T[];
  loading: boolean;
  error: string | null;
  isLive: boolean;
  add: (data: Omit<T, 'id'>) => Promise<string | null>;
  set: (id: string, data: Partial<T>, merge?: boolean) => Promise<boolean>;
  update: (id: string, data: Partial<T>) => Promise<boolean>;
  remove: (id: string) => Promise<boolean>;
  refresh: () => void;
} {
  const isFirebaseEnabled = useMemo(() => isFirebaseConfigured(), []);

  const firestore = useFirestore<T>(collectionName, {
    ...options,
    enabled: Boolean(collectionName),
  });

  return useMemo(() => {
    // When backed by live Firestore without error, trust the live collection (even when empty,
    // e.g. after deleting the last record or for a brand-new authenticated user account).
    // When in local/demo mode (or if Firestore returned a permission error for an unauthenticated preview),
    // fall back to sampleData when no records exist yet.
    const shouldUseSampleFallback =
      sampleData.length > 0 &&
      firestore.documents.length === 0 &&
      (!firestore.isCloud || Boolean(firestore.error));

    const resolvedData = shouldUseSampleFallback ? sampleData : firestore.documents;

    return {
      data: resolvedData,
      loading: isFirebaseEnabled ? firestore.loading : false,
      error: isFirebaseEnabled ? firestore.error : null,
      isLive: firestore.isCloud && !firestore.error,
      add: firestore.add,
      set: firestore.set,
      update: firestore.update,
      remove: firestore.remove,
      refresh: firestore.refresh,
    };
  }, [isFirebaseEnabled, firestore, sampleData]);
}
