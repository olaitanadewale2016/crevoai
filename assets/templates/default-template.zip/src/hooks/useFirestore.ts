import { useState, useEffect, useCallback, useMemo } from 'react';
import {
    collection,
    onSnapshot,
    addDoc,
    updateDoc,
    deleteDoc,
    doc,
    query,
    QueryConstraint,
    DocumentData,
} from 'firebase/firestore';
import { getDb, getCollectionPrefix } from '../lib/firebase';

export interface UseFirestoreOptions {
    /** Additional query constraints (where, orderBy, limit, etc.) */
    constraints?: QueryConstraint[];
    /** Whether to enable the Firestore subscription (default: true) */
    enabled?: boolean;
}

interface UseFirestoreReturn<T> {
    /** Array of documents with their IDs */
    documents: (T & { id: string })[];
    /** Loading state */
    loading: boolean;
    /** Error message if any */
    error: string | null;
    /** Add a new document */
    add: (data: Omit<T, 'id'>) => Promise<string | null>;
    /** Update an existing document */
    update: (id: string, data: Partial<T>) => Promise<boolean>;
    /** Delete a document */
    remove: (id: string) => Promise<boolean>;
    /** Refresh the documents (re-subscribe) */
    refresh: () => void;
}

/**
 * Hook for managing Firestore collections with real-time updates.
 * Automatically prefixes collection names with the project's Firebase prefix
 * and persists locally via localStorage when Firebase is disabled or unreachable.
 */
export function useFirestore<T extends DocumentData>(
    collectionName: string,
    options: UseFirestoreOptions = {}
): UseFirestoreReturn<T> {
    const [documents, setDocuments] = useState<(T & { id: string })[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [refreshKey, setRefreshKey] = useState(0);

    const { constraints = [], enabled = true } = options;

    const db = getDb();
    const prefix = getCollectionPrefix();

    // Memoize fullPath to prevent infinite loops and scope localStorage per project
    const fullPath = useMemo(
        () => prefix ? `${prefix}/${collectionName}` : collectionName,
        [prefix, collectionName]
    );
    const storageKey = `crevo_col_${fullPath}`;

    const loadFromStorage = useCallback((): (T & { id: string })[] => {
        try {
            const raw = typeof window !== 'undefined' ? localStorage.getItem(storageKey) : null;
            if (!raw) return [];
            const parsed = JSON.parse(raw);
            return Array.isArray(parsed) ? parsed : [];
        } catch {
            return [];
        }
    }, [storageKey]);

    const saveToStorage = useCallback((items: (T & { id: string })[]) => {
        try {
            if (typeof window !== 'undefined') {
                localStorage.setItem(storageKey, JSON.stringify(items));
            }
        } catch {}
    }, [storageKey]);

    const addLocal = useCallback((data: Omit<T, 'id'>): string => {
        const newId = 'doc-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
        const newDoc = { ...(data as Record<string, unknown>), id: newId } as T & { id: string };
        setDocuments(prev => {
            const updated = [newDoc, ...prev];
            saveToStorage(updated);
            return updated;
        });
        return newId;
    }, [saveToStorage]);

    const updateLocal = useCallback((id: string, data: Partial<T>): boolean => {
        setDocuments(prev => {
            const updated = prev.map(item =>
                item.id === id ? { ...item, ...(data as Partial<T & { id: string }>) } : item
            );
            saveToStorage(updated);
            return updated;
        });
        return true;
    }, [saveToStorage]);

    const removeLocal = useCallback((id: string): boolean => {
        setDocuments(prev => {
            const updated = prev.filter(item => item.id !== id);
            saveToStorage(updated);
            return updated;
        });
        return true;
    }, [saveToStorage]);

    useEffect(() => {
        // Skip if disabled or no collection name
        if (!enabled || !collectionName) {
            setLoading(false);
            setDocuments([]);
            return;
        }

        if (!db) {
            setLoading(false);
            setDocuments(loadFromStorage());
            return;
        }

        setLoading(true);
        setError(null);

        const q = query(collection(db, fullPath), ...constraints);

        const unsubscribe = onSnapshot(
            q,
            (snapshot) => {
                const docs = snapshot.docs.map((d) => ({
                    ...(d.data() as T),
                    id: d.id,
                }));
                setDocuments(docs);
                setLoading(false);
            },
            (err) => {
                console.error('Firestore error:', err);
                setError(err.message);
                setDocuments(loadFromStorage());
                setLoading(false);
            }
        );

        return () => unsubscribe();
    }, [db, fullPath, refreshKey, enabled, collectionName, constraints, loadFromStorage]);

    const add = useCallback(
        async (data: Omit<T, 'id'>): Promise<string | null> => {
            if (!db) {
                return addLocal(data);
            }

            try {
                const docRef = await addDoc(collection(db, fullPath), data as DocumentData);
                return docRef.id;
            } catch (err) {
                const message = err instanceof Error ? err.message : 'Failed to add document';
                setError(message);
                console.error('Error adding document:', err);
                return addLocal(data);
            }
        },
        [db, fullPath, addLocal]
    );

    const update = useCallback(
        async (id: string, data: Partial<T>): Promise<boolean> => {
            if (!db) {
                return updateLocal(id, data);
            }

            try {
                await updateDoc(doc(db, fullPath, id), data as DocumentData);
                return true;
            } catch (err) {
                const message = err instanceof Error ? err.message : 'Failed to update document';
                setError(message);
                console.error('Error updating document:', err);
                return updateLocal(id, data);
            }
        },
        [db, fullPath, updateLocal]
    );

    const remove = useCallback(
        async (id: string): Promise<boolean> => {
            if (!db) {
                return removeLocal(id);
            }

            try {
                await deleteDoc(doc(db, fullPath, id));
                return true;
            } catch (err) {
                const message = err instanceof Error ? err.message : 'Failed to delete document';
                setError(message);
                console.error('Error deleting document:', err);
                return removeLocal(id);
            }
        },
        [db, fullPath, removeLocal]
    );

    const refresh = useCallback(() => {
        setRefreshKey((prev) => prev + 1);
    }, []);

    return {
        documents,
        loading,
        error,
        add,
        update,
        remove,
        refresh,
    };
}
