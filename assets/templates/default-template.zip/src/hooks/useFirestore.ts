import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
    collection,
    onSnapshot,
    addDoc,
    setDoc,
    updateDoc,
    deleteDoc,
    doc,
    query,
    QueryConstraint,
    DocumentData,
} from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import {
    getDb,
    getFirebaseAuth,
    getCollectionPath,
    getUserCollectionPath,
    sanitizeFirestoreData,
    mapFirestoreError,
} from '../lib/firebase';

const EMPTY_CONSTRAINTS: QueryConstraint[] = [];

export interface UseFirestoreOptions {
    /** Additional query constraints (where, orderBy, limit, etc.) */
    constraints?: QueryConstraint[];
    /** Whether to enable the Firestore subscription (default: true) */
    enabled?: boolean;
    /**
     * When true, automatically scopes the collection under `users/<uid>/<collectionName>`
     * for the signed-in Firebase user (falls back to local guest storage when signed out).
     */
    userScoped?: boolean;
}

interface UseFirestoreReturn<T> {
    /** Array of documents with their IDs */
    documents: (T & { id: string })[];
    /** Loading state */
    loading: boolean;
    /** Error message if any */
    error: string | null;
    /** True when actively synced with cloud Firestore (false in localStorage fallback mode) */
    isCloud: boolean;
    /** Add a new document with an auto-generated ID */
    add: (data: Omit<T, 'id'>) => Promise<string | null>;
    /** Create or update a document with a specific ID (defaults to merge: true) */
    set: (id: string, data: Partial<T>, merge?: boolean) => Promise<boolean>;
    /** Update an existing document */
    update: (id: string, data: Partial<T>) => Promise<boolean>;
    /** Delete a document */
    remove: (id: string) => Promise<boolean>;
    /** Refresh the documents (re-subscribe) */
    refresh: () => void;
}

/**
 * Subscribe to Firebase Auth UID changes so Firestore listeners automatically
 * reconnect after session restoration, sign-in, or sign-out.
 */
function useFirebaseAuthUid(): { uid: string | null; authReady: boolean } {
    const auth = getFirebaseAuth();
    const [state, setState] = useState<{ uid: string | null; authReady: boolean }>(() => ({
        uid: auth?.currentUser?.uid ?? null,
        authReady: !auth,
    }));

    useEffect(() => {
        const activeAuth = getFirebaseAuth();
        if (!activeAuth) {
            setState({ uid: null, authReady: true });
            return;
        }

        const unsubscribe = onAuthStateChanged(
            activeAuth,
            (firebaseUser) => {
                setState({ uid: firebaseUser?.uid ?? null, authReady: true });
            },
            () => {
                setState({ uid: null, authReady: true });
            }
        );

        return () => unsubscribe();
    }, [auth]);

    return state;
}

/**
 * Build a stable key for QueryConstraint arrays so inline constraints like
 * `constraints: [where('userId', '==', uid)]` do not trigger infinite re-subscribes.
 */
function getConstraintsSignature(constraints: QueryConstraint[]): string {
    if (!constraints || constraints.length === 0) return '';
    try {
        return JSON.stringify(
            constraints.map((c) => {
                const raw = c as unknown as Record<string, unknown>;
                return {
                    type: c.type,
                    fields: raw._field ?? raw._fieldPath ?? null,
                    op: raw._op ?? null,
                    value: raw._value ?? null,
                    dir: raw._direction ?? null,
                    limit: raw._limit ?? null,
                };
            })
        );
    } catch {
        return String(constraints.length);
    }
}

/**
 * Hook for managing Firestore collections with real-time updates.
 * Automatically prefixes collection names with the project's Firebase prefix,
 * reconnects automatically when Firebase Auth state changes, strips undefined fields,
 * and falls back to localStorage only when Firebase is not configured (or guest mode).
 */
export function useFirestore<T extends DocumentData>(
    collectionName: string,
    options: UseFirestoreOptions = {}
): UseFirestoreReturn<T> {
    const [documents, setDocuments] = useState<(T & { id: string })[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [refreshKey, setRefreshKey] = useState(0);

    const { constraints = EMPTY_CONSTRAINTS, enabled = true, userScoped = false } = options;

    const db = getDb();
    const { uid, authReady } = useFirebaseAuthUid();

    // Keep latest constraints in a ref keyed by a stable serialized signature
    const constraintsSig = getConstraintsSignature(constraints);
    const constraintsRef = useRef<QueryConstraint[]>(constraints);
    constraintsRef.current = constraints;

    const effectiveCollection = useMemo(() => {
        const clean = (collectionName || '').replace(/^\/+|\/+$/g, '');
        if (!clean) return '';
        if (userScoped) {
            return uid ? getUserCollectionPath(uid, clean) : `guest/${clean}`;
        }
        return clean;
    }, [collectionName, userScoped, uid]);

    const fullPath = useMemo(() => {
        if (!effectiveCollection) return '';
        return getCollectionPath(effectiveCollection);
    }, [effectiveCollection]);

    const isCloud = Boolean(db && enabled && fullPath && (!userScoped || uid));
    const storageKey = `crevo_col_${fullPath || 'empty'}`;

    const loadFromStorage = useCallback((): (T & { id: string })[] => {
        try {
            const raw = typeof window !== 'undefined' ? localStorage.getItem(storageKey) : null;
            if (!raw) return [];
            const parsed = JSON.parse(raw);
            return Array.isArray(parsed) ? parsed : [];
        } catch {
            return [];
        }
    }, [storageKey]);

    const saveToStorage = useCallback((items: (T & { id: string })[]) => {
        try {
            if (typeof window !== 'undefined') {
                localStorage.setItem(storageKey, JSON.stringify(items));
            }
        } catch {
            // Ignore localStorage quota errors
        }
    }, [storageKey]);

    const addLocal = useCallback((data: Omit<T, 'id'>): string => {
        const newId = 'doc-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
        const cleaned = sanitizeFirestoreData(data as Record<string, unknown>);
        const newDoc = { ...cleaned, id: newId } as T & { id: string };
        setDocuments((prev) => {
            const updated = [newDoc, ...prev];
            saveToStorage(updated);
            return updated;
        });
        return newId;
    }, [saveToStorage]);

    const setLocal = useCallback((id: string, data: Partial<T>, merge = true): boolean => {
        const cleaned = sanitizeFirestoreData(data as Record<string, unknown>);
        setDocuments((prev) => {
            const exists = prev.some((item) => item.id === id);
            const updated = exists
                ? prev.map((item) =>
                      item.id === id
                          ? (merge ? { ...item, ...cleaned, id } : { ...cleaned, id }) as T & { id: string }
                          : item
                  )
                : [{ ...cleaned, id } as T & { id: string }, ...prev];
            saveToStorage(updated);
            return updated;
        });
        return true;
    }, [saveToStorage]);

    const updateLocal = useCallback((id: string, data: Partial<T>): boolean => {
        const cleaned = sanitizeFirestoreData(data as Record<string, unknown>);
        setDocuments((prev) => {
            const updated = prev.map((item) =>
                item.id === id ? { ...item, ...(cleaned as Partial<T & { id: string }>) } : item
            );
            saveToStorage(updated);
            return updated;
        });
        return true;
    }, [saveToStorage]);

    const removeLocal = useCallback((id: string): boolean => {
        setDocuments((prev) => {
            const updated = prev.filter((item) => item.id !== id);
            saveToStorage(updated);
            return updated;
        });
        return true;
    }, [saveToStorage]);

    useEffect(() => {
        if (!enabled || !fullPath) {
            setLoading(false);
            setDocuments([]);
            setError(null);
            return;
        }

        // Wait briefly for Firebase Auth persistence to hydrate before attaching cloud listeners
        // so authenticated users never hit a spurious PERMISSION_DENIED on initial page load.
        if (db && !authReady) {
            setLoading(true);
            return;
        }

        // Fall back to localStorage only when Firebase is not configured OR userScoped is in guest mode
        if (!db || (userScoped && !uid)) {
            setLoading(false);
            setError(null);
            setDocuments(loadFromStorage());
            return;
        }

        setLoading(true);
        setError(null);

        const activeConstraints = constraintsRef.current;
        const q = activeConstraints.length > 0
            ? query(collection(db, fullPath), ...activeConstraints)
            : collection(db, fullPath);

        const unsubscribe = onSnapshot(
            q,
            (snapshot) => {
                const docs = snapshot.docs.map((d) => ({
                    ...(d.data() as T),
                    id: d.id,
                }));
                setDocuments(docs);
                setError(null);
                setLoading(false);
            },
            (err) => {
                console.error(`Firestore subscription error (${fullPath}):`, err);
                setError(mapFirestoreError(err));
                setLoading(false);
            }
        );

        return () => unsubscribe();
    }, [db, fullPath, refreshKey, enabled, constraintsSig, userScoped, uid, authReady, loadFromStorage]);

    const add = useCallback(
        async (data: Omit<T, 'id'>): Promise<string | null> => {
            if (!fullPath) {
                setError('Collection path is not ready.');
                return null;
            }
            const activeDb = db ?? getDb();
            if (!activeDb || (userScoped && !uid)) {
                return addLocal(data);
            }

            try {
                setError(null);
                const payload = sanitizeFirestoreData(data as DocumentData);
                const docRef = await addDoc(collection(activeDb, fullPath), payload);
                return docRef.id;
            } catch (err) {
                const message = mapFirestoreError(err);
                setError(message);
                console.error(`Error adding Firestore document (${fullPath}):`, err);
                return null;
            }
        },
        [db, fullPath, userScoped, uid, addLocal]
    );

    const set = useCallback(
        async (id: string, data: Partial<T>, merge = true): Promise<boolean> => {
            if (!fullPath || !id) {
                setError('Collection path and document ID are required.');
                return false;
            }
            const activeDb = db ?? getDb();
            if (!activeDb || (userScoped && !uid)) {
                return setLocal(id, data, merge);
            }

            try {
                setError(null);
                const payload = sanitizeFirestoreData(data as DocumentData);
                await setDoc(doc(activeDb, fullPath, id), payload, { merge });
                return true;
            } catch (err) {
                const message = mapFirestoreError(err);
                setError(message);
                console.error(`Error setting Firestore document (${fullPath}/${id}):`, err);
                return false;
            }
        },
        [db, fullPath, userScoped, uid, setLocal]
    );

    const update = useCallback(
        async (id: string, data: Partial<T>): Promise<boolean> => {
            if (!fullPath || !id) {
                setError('Collection path and document ID are required.');
                return false;
            }
            const activeDb = db ?? getDb();
            if (!activeDb || (userScoped && !uid)) {
                return updateLocal(id, data);
            }

            try {
                setError(null);
                const payload = sanitizeFirestoreData(data as DocumentData);
                await updateDoc(doc(activeDb, fullPath, id), payload);
                return true;
            } catch (err) {
                const message = mapFirestoreError(err);
                setError(message);
                console.error(`Error updating Firestore document (${fullPath}/${id}):`, err);
                return false;
            }
        },
        [db, fullPath, userScoped, uid, updateLocal]
    );

    const remove = useCallback(
        async (id: string): Promise<boolean> => {
            if (!fullPath || !id) {
                setError('Collection path and document ID are required.');
                return false;
            }
            const activeDb = db ?? getDb();
            if (!activeDb || (userScoped && !uid)) {
                return removeLocal(id);
            }

            try {
                setError(null);
                await deleteDoc(doc(activeDb, fullPath, id));
                return true;
            } catch (err) {
                const message = mapFirestoreError(err);
                setError(message);
                console.error(`Error deleting Firestore document (${fullPath}/${id}):`, err);
                return false;
            }
        },
        [db, fullPath, userScoped, uid, removeLocal]
    );

    const refresh = useCallback(() => {
        setRefreshKey((prev) => prev + 1);
    }, []);

    return {
        documents,
        loading,
        error,
        isCloud,
        add,
        set,
        update,
        remove,
        refresh,
    };
}

/**
 * Convenience hook for per-user private Firestore collections (e.g. menstrual cycle logs,
 * journals, health entries, saved items). Stores documents under `users/<uid>/<collectionName>`
 * when authenticated so no composite indexes are needed and each user's data is isolated.
 */
export function useUserFirestore<T extends DocumentData>(
    collectionName: string,
    options: Omit<UseFirestoreOptions, 'userScoped'> = {}
): UseFirestoreReturn<T> {
    return useFirestore<T>(collectionName, { ...options, userScoped: true });
}

interface UseFirestoreDocReturn<T> {
    /** Current document data (with id) or null if not created yet */
    data: (T & { id: string }) | null;
    /** Loading state */
    loading: boolean;
    /** Error message if any */
    error: string | null;
    /** True when backed by live Firestore */
    isCloud: boolean;
    /** Create or update the document (defaults to merge: true) */
    save: (data: Partial<T>, merge?: boolean) => Promise<boolean>;
    /** Delete the document */
    remove: () => Promise<boolean>;
    /** Force re-subscribe */
    refresh: () => void;
}

/**
 * Real-time hook for a single Firestore document (ideal for per-user profiles & settings,
 * e.g. `useFirestoreDoc<UserCycleProfile>('users', user?.uid)`).
 */
export function useFirestoreDoc<T extends DocumentData>(
    collectionName: string,
    documentId: string | null | undefined,
    options: { enabled?: boolean } = {}
): UseFirestoreDocReturn<T> {
    const { enabled = true } = options;
    const [data, setData] = useState<(T & { id: string }) | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [refreshKey, setRefreshKey] = useState(0);

    const db = getDb();
    const { authReady } = useFirebaseAuthUid();

    const fullCollectionPath = useMemo(
        () => (collectionName ? getCollectionPath(collectionName) : ''),
        [collectionName]
    );
    const cleanDocId = (documentId || '').trim();
    const isCloud = Boolean(db && enabled && fullCollectionPath && cleanDocId);
    const storageKey = `crevo_doc_${fullCollectionPath}_${cleanDocId || 'guest'}`;

    const loadLocal = useCallback((): (T & { id: string }) | null => {
        try {
            const raw = typeof window !== 'undefined' ? localStorage.getItem(storageKey) : null;
            if (!raw) return null;
            return JSON.parse(raw) as T & { id: string };
        } catch {
            return null;
        }
    }, [storageKey]);

    const saveLocal = useCallback((docData: (T & { id: string }) | null) => {
        try {
            if (typeof window === 'undefined') return;
            if (docData === null) {
                localStorage.removeItem(storageKey);
            } else {
                localStorage.setItem(storageKey, JSON.stringify(docData));
            }
        } catch {
            // Ignore localStorage quota errors
        }
    }, [storageKey]);

    useEffect(() => {
        if (!enabled || !fullCollectionPath || !cleanDocId) {
            setData(null);
            setError(null);
            setLoading(false);
            return;
        }

        if (db && !authReady) {
            setLoading(true);
            return;
        }

        if (!db) {
            setData(loadLocal());
            setError(null);
            setLoading(false);
            return;
        }

        setLoading(true);
        setError(null);

        const docRef = doc(db, fullCollectionPath, cleanDocId);
        const unsubscribe = onSnapshot(
            docRef,
            (snapshot) => {
                if (snapshot.exists()) {
                    setData({ ...(snapshot.data() as T), id: snapshot.id });
                } else {
                    setData(null);
                }
                setError(null);
                setLoading(false);
            },
            (err) => {
                console.error(`Firestore doc error (${fullCollectionPath}/${cleanDocId}):`, err);
                setError(mapFirestoreError(err));
                setLoading(false);
            }
        );

        return () => unsubscribe();
    }, [db, fullCollectionPath, cleanDocId, enabled, authReady, refreshKey, loadLocal]);

    const save = useCallback(
        async (partialData: Partial<T>, merge = true): Promise<boolean> => {
            if (!fullCollectionPath || !cleanDocId) {
                setError('Document path is not ready.');
                return false;
            }
            const cleaned = sanitizeFirestoreData(partialData as DocumentData);
            const activeDb = db ?? getDb();
            if (!activeDb) {
                setData((prev) => {
                    const next = (
                        merge && prev ? { ...prev, ...cleaned, id: cleanDocId } : { ...cleaned, id: cleanDocId }
                    ) as T & { id: string };
                    saveLocal(next);
                    return next;
                });
                return true;
            }

            try {
                setError(null);
                await setDoc(doc(activeDb, fullCollectionPath, cleanDocId), cleaned, { merge });
                return true;
            } catch (err) {
                const message = mapFirestoreError(err);
                setError(message);
                console.error(`Error saving Firestore document (${fullCollectionPath}/${cleanDocId}):`, err);
                return false;
            }
        },
        [db, fullCollectionPath, cleanDocId, saveLocal]
    );

    const remove = useCallback(async (): Promise<boolean> => {
        if (!fullCollectionPath || !cleanDocId) return false;
        const activeDb = db ?? getDb();
        if (!activeDb) {
            setData(null);
            saveLocal(null);
            return true;
        }
        try {
            setError(null);
            await deleteDoc(doc(activeDb, fullCollectionPath, cleanDocId));
            return true;
        } catch (err) {
            const message = mapFirestoreError(err);
            setError(message);
            return false;
        }
    }, [db, fullCollectionPath, cleanDocId, saveLocal]);

    const refresh = useCallback(() => {
        setRefreshKey((prev) => prev + 1);
    }, []);

    return {
        data,
        loading,
        error,
        isCloud,
        save,
        remove,
        refresh,
    };
}
