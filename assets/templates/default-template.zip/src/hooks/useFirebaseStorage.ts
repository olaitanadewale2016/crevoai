import { useState, useCallback } from 'react';
import {
    ref,
    uploadBytesResumable,
    getDownloadURL,
    deleteObject,
    listAll,
} from 'firebase/storage';
import {
    getFirebaseStorage,
    getFirebaseAuth,
    getCollectionPrefix,
} from '../lib/firebase';

export interface FirebaseStoredFile {
    name: string;
    fullPath: string;
    url: string;
    size?: number;
    contentType?: string;
}

/**
 * Hook for uploading, listing, and deleting files in Firebase Cloud Storage.
 * Automatically namespaces files under `<firebasePrefix>/uploads/<uid|public>/...`.
 */
export function useFirebaseStorage() {
    const [uploading, setUploading] = useState(false);
    const [progress, setProgress] = useState(0);
    const [error, setError] = useState<string | null>(null);

    const storage = getFirebaseStorage();
    const isConfigured = Boolean(storage);

    const buildBaseFolder = useCallback((folder?: string): string => {
        const prefix = getCollectionPrefix();
        const uid = getFirebaseAuth()?.currentUser?.uid;
        const ownerScope = uid ? `users/${uid}` : 'public';
        const cleanFolder = (folder || '').replace(/^\/+|\/+$/g, '');
        return [prefix, 'uploads', ownerScope, cleanFolder].filter(Boolean).join('/');
    }, []);

    const upload = useCallback(
        async (file: File, folder?: string): Promise<FirebaseStoredFile | null> => {
            const activeStorage = storage ?? getFirebaseStorage();
            if (!activeStorage) {
                setError('Firebase Storage is not configured for this project.');
                return null;
            }

            setUploading(true);
            setProgress(0);
            setError(null);

            try {
                const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
                const uniqueName = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${safeName}`;
                const fullPath = `${buildBaseFolder(folder)}/${uniqueName}`;
                const storageRef = ref(activeStorage, fullPath);

                const url = await new Promise<string>((resolve, reject) => {
                    const task = uploadBytesResumable(storageRef, file, {
                        contentType: file.type || 'application/octet-stream',
                    });

                    task.on(
                        'state_changed',
                        (snapshot) => {
                            if (snapshot.totalBytes > 0) {
                                setProgress(Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100));
                            }
                        },
                        (err) => reject(err),
                        async () => {
                            try {
                                const downloadUrl = await getDownloadURL(task.snapshot.ref);
                                resolve(downloadUrl);
                            } catch (e) {
                                reject(e);
                            }
                        }
                    );
                });

                setProgress(100);
                return {
                    name: file.name,
                    fullPath,
                    url,
                    size: file.size,
                    contentType: file.type || 'application/octet-stream',
                };
            } catch (err) {
                const rawMsg = err instanceof Error ? err.message : 'Firebase Storage upload failed';
                const friendly = rawMsg.includes('storage/unauthorized')
                    ? 'Upload denied by Firebase Storage security rules. Sign in or deploy the project Storage rules in Firebase Console.'
                    : rawMsg;
                setError(friendly);
                return null;
            } finally {
                setUploading(false);
            }
        },
        [storage, buildBaseFolder]
    );

    const deleteFile = useCallback(
        async (fullPath: string): Promise<boolean> => {
            const activeStorage = storage ?? getFirebaseStorage();
            if (!activeStorage || !fullPath) {
                setError('Firebase Storage is not configured.');
                return false;
            }

            try {
                setError(null);
                await deleteObject(ref(activeStorage, fullPath));
                return true;
            } catch (err) {
                const message = err instanceof Error ? err.message : 'Failed to delete file';
                setError(message);
                return false;
            }
        },
        [storage]
    );

    const listFiles = useCallback(
        async (folder?: string): Promise<FirebaseStoredFile[]> => {
            const activeStorage = storage ?? getFirebaseStorage();
            if (!activeStorage) return [];

            try {
                setError(null);
                const listRef = ref(activeStorage, buildBaseFolder(folder));
                const result = await listAll(listRef);
                const items = await Promise.all(
                    result.items.map(async (itemRef) => ({
                        name: itemRef.name,
                        fullPath: itemRef.fullPath,
                        url: await getDownloadURL(itemRef),
                    }))
                );
                return items;
            } catch (err) {
                const message = err instanceof Error ? err.message : 'Failed to list files';
                setError(message);
                return [];
            }
        },
        [storage, buildBaseFolder]
    );

    return {
        upload,
        deleteFile,
        listFiles,
        uploading,
        progress,
        error,
        isConfigured,
    };
}
