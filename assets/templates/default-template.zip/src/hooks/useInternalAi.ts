import { useState, useCallback } from 'react';

export interface InternalAiMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface InternalAiOptions {
  systemPrompt?: string;
  maxTokens?: number;
  temperature?: number;
}

export interface InternalAiResult {
  text: string;
  model?: string;
  provider?: string;
}

/**
 * Admin-only hook for invoking the platform's configured Internal AI Provider
 * (e.g. Gemini) securely through the server proxy without exposing API keys.
 *
 * Strictly available ONLY on projects owned by an administrator (`window.__APP_CONFIG__.internalAiEnabled === true`).
 */
export function useInternalAi() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const config = typeof window !== 'undefined' ? window.__APP_CONFIG__ : undefined;
  const apiBase = (
    config?.apiUrl ||
    (typeof window !== 'undefined' ? window.location.origin : '')
  ).replace(/\/+$/, '');

  const isConfigured = Boolean(
    config?.internalAiEnabled === true && config?.projectId && config?.apiToken
  );

  const invoke = useCallback(
    async (payload: Record<string, unknown>): Promise<InternalAiResult | null> => {
      if (!config?.projectId || !config?.apiToken || config?.internalAiEnabled !== true) {
        setError('Internal AI provider is restricted to administrator projects.');
        return null;
      }

      setLoading(true);
      setError(null);

      try {
        const res = await fetch(`${apiBase}/api/app/${config.projectId}/ai`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Project-Token': config.apiToken,
          },
          body: JSON.stringify(payload),
        });

        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          throw new Error(data.error || data.message || `Internal AI request failed (${res.status})`);
        }

        return {
          text: String(data.text ?? data.content ?? ''),
          model: data.model,
          provider: data.provider,
        };
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Internal AI request failed';
        setError(msg);
        return null;
      } finally {
        setLoading(false);
      }
    },
    [config, apiBase]
  );

  const generate = useCallback(
    async (prompt: string, options?: InternalAiOptions): Promise<InternalAiResult | null> => {
      return invoke({
        prompt,
        ...(options?.systemPrompt ? { systemPrompt: options.systemPrompt } : {}),
        ...(options?.maxTokens ? { maxTokens: options.maxTokens } : {}),
        ...(options?.temperature !== undefined ? { temperature: options.temperature } : {}),
      });
    },
    [invoke]
  );

  const chat = useCallback(
    async (
      messages: InternalAiMessage[],
      options?: InternalAiOptions
    ): Promise<InternalAiResult | null> => {
      return invoke({
        messages,
        ...(options?.systemPrompt ? { systemPrompt: options.systemPrompt } : {}),
        ...(options?.maxTokens ? { maxTokens: options.maxTokens } : {}),
        ...(options?.temperature !== undefined ? { temperature: options.temperature } : {}),
      });
    },
    [invoke]
  );

  return {
    generate,
    chat,
    loading,
    error,
    isConfigured,
  };
}
