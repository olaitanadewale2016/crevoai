import { useState, useCallback } from 'react';

export interface StoredFile {
    id: string | number;
    url: string;
    filename: string;
    original_filename: string;
    mime_type: string;
    size: number;
    human_size?: string;
    created_at?: string;
}

interface UploadResponse {
    file: StoredFile;
    storage_used?: number;
}

/**
 * Hook for managing file storage via the System Storage API.
 *
 * Usage:
 * ```tsx
 * const { upload, deleteFile, getFiles, uploading, error, isConfigured } = useSystemStorage();
 * ```
 */
export function useSystemStorage() {
    const [uploading, setUploading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const config = typeof window !== 'undefined' ? window.__APP_CONFIG__ : undefined;
    const apiBase = (
        config?.apiUrl ||
        (typeof window !== 'undefined' ? window.location.origin : '')
    ).replace(/\/+$/, '');

    const isConfigured = Boolean(
        config?.projectId &&
        config?.apiToken &&
        config?.storageEnabled !== false
    );

    const upload = useCallback(async (file: File): Promise<StoredFile | null> => {
        if (!config?.projectId || !config?.apiToken) {
            setError('File storage is not configured for this project.');
            return null;
        }
        if (config.storageEnabled === false) {
            setError('File storage is not enabled on this project plan.');
            return null;
        }

        setUploading(true);
        setError(null);

        try {
            const formData = new FormData();
            formData.append('file', file);

            const response = await fetch(`${apiBase}/api/app/${config.projectId}/files`, {
                method: 'POST',
                headers: {
                    'X-Project-Token': config.apiToken,
                },
                body: formData,
            });

            if (!response.ok) {
                const data = await response.json().catch(() => ({}));
                throw new Error(data.error || data.message || `Upload failed (${response.status})`);
            }

            const data: UploadResponse = await response.json();
            return data.file;
        } catch (err) {
            const message = err instanceof Error ? err.message : 'Upload failed';
            setError(message);
            return null;
        } finally {
            setUploading(false);
        }
    }, [config, apiBase]);

    const deleteFile = useCallback(async (fileId: string | number): Promise<boolean> => {
        if (!config?.projectId || !config?.apiToken) {
            setError('Storage not configured');
            return false;
        }

        try {
            setError(null);
            const response = await fetch(`${apiBase}/api/app/${config.projectId}/files/${encodeURIComponent(String(fileId))}`, {
                method: 'DELETE',
                headers: {
                    'X-Project-Token': config.apiToken,
                },
            });
            if (!response.ok) {
                const data = await response.json().catch(() => ({}));
                setError(data.error || 'Failed to delete file');
                return false;
            }
            return true;
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to delete file');
            return false;
        }
    }, [config, apiBase]);

    const getFiles = useCallback(async (): Promise<StoredFile[]> => {
        if (!config?.projectId || !config?.apiToken) {
            return [];
        }

        try {
            setError(null);
            const response = await fetch(`${apiBase}/api/app/${config.projectId}/files`, {
                headers: {
                    'X-Project-Token': config.apiToken,
                },
            });

            if (!response.ok) {
                return [];
            }

            const data = await response.json();
            return data.files || [];
        } catch {
            return [];
        }
    }, [config, apiBase]);

    return {
        upload,
        deleteFile,
        getFiles,
        uploading,
        error,
        isConfigured,
    };
}
